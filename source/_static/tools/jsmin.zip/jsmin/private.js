"use strict";
//查询余额
function queryBanance(address)
{
    return Chain.getBalance(address);
}
//初始化
function init(input)
{
  return;
}
function main(input)
{
    let args = JSON.parse(input);
    if(args.method === "input"){
        return 1;
    }
}
function query(input)
{
    let args = JSON.parse(input);
    if(args.method === "queryBanance"){
        return queryBanance(args.params.address);
    }
}